import {

  makeWASocket,

  useMultiFileAuthState,

  fetchLatestBaileysVersion,

  makeCacheableSignalKeyStore,

  DisconnectReason

} from '@whiskeysockets/baileys'

import Pino from 'pino'

import chalk from 'chalk'

import fs from 'fs'

import path from 'path'

import dotenv from 'dotenv'

import readline from 'readline'

import { fileURLToPath } from 'url'

// Charger les variables d'environnement

dotenv.config()

// ────────────── CONFIGURATION ──────────────

const __filename = fileURLToPath(import.meta.url)

const __dirname = path.dirname(__filename)

const OWNER_JIDS = [

  '200420857253947@lid',

  '24106438078@s.whatsapp.net'

]

const COMMAND_REACTION = '🔞'

// ────────────── COMMANDES & MODULES ──────────────

const commandsPath = path.join(__dirname, 'commands')

const commands = new Map()

let emmaHandler = null

let shadowFunctions = {}

let handleMentionEvent = null

let handleWelcomeEvent = null

// ────────────── CHARGEMENT DES MODULES ──────────────

async function loadShadowFunctions() {

  const shadowPath = path.join(__dirname, 'shadow.js')

  if (fs.existsSync(shadowPath)) {

    try {

      const shadowModule = await import(`file://${shadowPath}`)

      shadowFunctions = shadowModule

      console.log(chalk.green('✓ 🛡️ Fonctions shadow chargées'))

      const functionNames = Object.keys(shadowModule).filter(k => typeof shadowModule[k] === 'function')

      console.log(chalk.cyan(`📚 Fonctions disponibles: ${functionNames.join(', ')}`))

    } catch (err) {

      console.log(chalk.red(`✗ ❌ Erreur shadow.js: ${err.message}`))

    }

  } else console.log(chalk.yellow('⚠️ Fichier shadow.js non trouvé'))

}

async function loadCommands() {

  if (fs.existsSync(commandsPath)) {

    const files = fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'))

    for (const file of files) {

      try {

        const command = await import(`file://${path.join(commandsPath, file)}`)

        

        // Charger mention handler

        if (file === 'mention.js' && command.handleMentionEvent) {

          handleMentionEvent = command.handleMentionEvent

          console.log(chalk.green('✓ 📢 Handler mention chargé'))

        }

        

        // Charger welcome handler

        if (file === 'welcome.js' && command.handleWelcomeEvent) {

          handleWelcomeEvent = command.handleWelcomeEvent

          console.log(chalk.green('✓ 👋 Handler welcome chargé'))

        }

        

        if (command.default?.name) {

          commands.set(command.default.name, command.default)

          console.log(chalk.green(`✓ ⚡ Commande chargée: ${command.default.name}`))

          

          if (command.default.name === 'emma' && command.default.handleEmmaResponse) {

            emmaHandler = command.default.handleEmmaResponse

            console.log(chalk.magenta('✓ 👸 Handler Emma chargé'))

          }

        }

      } catch (err) {

        console.log(chalk.red(`✗ ❌ Erreur ${file}: ${err.message}`))

      }

    }

  }

}

// ────────────── UTILITAIRES ──────────────

function question(q) {

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout })

  return new Promise(r => rl.question(q, a => { rl.close(); r(a) }))

}

function extractText(msg) {

  if (!msg.message) return ''

  if (msg.message.conversation) return msg.message.conversation

  if (msg.message.extendedTextMessage?.text) return msg.message.extendedTextMessage.text

  if (msg.message.imageMessage?.caption) return msg.message.imageMessage.caption

  if (msg.message.videoMessage?.caption) return msg.message.videoMessage.caption

  return ''

}

async function reactToMessage(sock, msg, emoji) {

  try {

    await sock.sendMessage(msg.key.remoteJid, {

      react: { text: emoji, key: msg.key }

    })

  } catch (err) {

    console.log(chalk.red(`❌ Erreur réaction: ${err.message}`))

  }

}

// ────────────── GESTION DES MESSAGES ──────────────

async function handleMessage(sock, message) {

  try {

    const sender = message.key.participant || message.key.remoteJid

    const text = extractText(message)

    if (!text) return

    // Protection anti-boucle pour le numéro du bot

    if (message.key.fromMe && !text.startsWith('.')) return

    // Commande

    if (text.startsWith('.')) {

      const args = text.slice(1).trim().split(/ +/)

      const commandName = args.shift().toLowerCase()

      const command = commands.get(commandName)

      if (!OWNER_JIDS.includes(sender) && command?.category === '⚙️ Général') return

      if (command) {

        await reactToMessage(sock, message, COMMAND_REACTION)

        await command.execute(sock, message, args, commands)

      }

    } else if (emmaHandler) {

      await emmaHandler(sock, message)

    }

  } catch (err) {

    console.error(chalk.red('❌ Erreur handleMessage:'), err)

  }

}

// ────────────── DÉMARRAGE DU BOT ──────────────

async function startBot() {

  await loadShadowFunctions()

  await loadCommands()

  let state, saveCreds

  try {

    ({ state, saveCreds } = await useMultiFileAuthState('./session'))

  } catch (err) {

    console.log(chalk.red('⚠️ Session invalide ou corrompue. Réinitialisation...'))

    fs.rmSync('./session', { recursive: true, force: true })

    ({ state, saveCreds } = await useMultiFileAuthState('./session'))

  }

  const { version } = await fetchLatestBaileysVersion()

  const sock = makeWASocket({

    version,

    logger: Pino({ level: 'silent' }),

    auth: {

      creds: state.creds,

      keys: makeCacheableSignalKeyStore(state.keys, Pino({ level: 'silent' }))

    },

    browser: ['Ubuntu', 'Chrome', '20.0.04'],

    printQRInTerminal: false

  })

  sock.ev.on('creds.update', saveCreds)

  sock.ev.on('connection.update', async ({ connection, lastDisconnect }) => {

    const reason = lastDisconnect?.error?.output?.statusCode

    if (connection === 'close') {

      console.log(chalk.red(`⚠️ Connexion fermée (${reason}).`))

      if (reason === DisconnectReason.loggedOut || reason === 401) {

        console.log(chalk.yellow('🔁 Réinitialisation de la session...'))

        fs.rmSync('./session', { recursive: true, force: true })

      }

      console.log(chalk.cyan('🔄 Reconnexion dans 5s...'))

      setTimeout(startBot, 5000)

    } else if (connection === 'open') {

      console.log(chalk.green.bold('\n✅ Bot connecté avec succès!'))

      console.log(chalk.magenta(`😈 Réactions activées avec: ${COMMAND_REACTION}`))

      console.log(chalk.cyan('🚀 En attente de commandes...\n'))

      if (shadowFunctions.protectionManager)

        console.log(chalk.cyan('🛡️ Protection Manager initialisé'))

    }

  })

  if (!state.creds?.registered) {

    const phone = await question(chalk.cyan('📱 Entre ton numéro WhatsApp (ex: 241XXXXXXXXX): '))

    const code = await sock.requestPairingCode(phone)

    console.log(chalk.magentaBright(`\n🔗 Code de couplage : ${code}\n`))

    console.log(chalk.green('👉 Ouvre WhatsApp → Appareils connectés → Lier un appareil → Lier avec un code.\n'))

  }

  // ✅ ÉVÉNEMENT MESSAGES

  sock.ev.on('messages.upsert', async ({ messages }) => {

    for (const msg of messages) {

      if (handleMentionEvent) await handleMentionEvent(sock, msg)

      await handleMessage(sock, msg)

    }

  })

  // ✅ ÉVÉNEMENT WELCOME (NOUVEAUX MEMBRES)

  sock.ev.on('group-participants.update', async (update) => {

    try {

      const { id, participants, action } = update

      console.log(chalk.cyan(`👥 Événement groupe: ${action} dans ${id}`))

      

      if (handleWelcomeEvent) {

        await handleWelcomeEvent(sock, id, participants, action)

      }

    } catch (err) {

      console.error(chalk.red('❌ Erreur group-participants.update:'), err)

    }

  })

}

// ────────────── BANNIÈRE ──────────────

console.log(chalk.magenta(`

┏━━┓╻ ╻┏━┓╺┓ ┏━╸╻ ╻   ╻ ╻┏┓ ┏━┓╺┳╸

┣━━┫┣━┫┣━┫ ┃ ┃  ┃ ┃   ┃ ┃┣┻┓┃ ┃ ┃

╹  ╹╹ ╹╹ ╹╺┻╸┗━╸┗━┛   ┗━┛┗━┛┗━┛ ╹

`))

console.log(chalk.cyan(`

▓▓▓▓▓▓╗     ╔═══════════════════════════╗

▓▓╔══▓▓╗    ║  🌙 DYNASTY MD X 🌙      ║

▓▓▓▓▓▓╔╝    ║  ✨ Version 1.0.0         ║

▓▓╔══▓▓╗    ║  ⚡ Script: fakeyt        ║

▓▓▓▓▓▓╔╝    ║  👑 Owner: Shadow Noctem  ║

╚══════╝    ╚═══════════════════════════╝

`))

console.log(chalk.blue.bold(`

╔═══════════════════════════════════╗

║  🤖 BOT WHATSAPP - PROPRIÉTAIRE   ║

║  😈 Par: Shadow Noctem abyss      ║

║  🔥 Status: Actif                 ║

╚═══════════════════════════════════╝

`))

console.log(chalk.yellow(`

⚡ Démarrage du système...

🛡️ Chargement des protections shadow...

📦 Initialisation des modules...

`))

startBot().catch(err => {

  console.error(chalk.red('❌ Erreur au démarrage:'), err)

  process.exit(1)

})