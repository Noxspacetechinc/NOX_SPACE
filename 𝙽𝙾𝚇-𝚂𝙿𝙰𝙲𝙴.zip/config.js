// Configuration du bot
export const config = {
  // 👑 Propriétaire du bot (VOUS)
  owner: '213557779423@s.whatasapp.net', // Remplacez par votre numéro
  
  // 💎 Utilisateurs premium (peuvent utiliser les commandes restreintes)
  premium: [
    '49986197449266626@s.whatasapp.net',  // Utilisateur premium 1
    // Ajoutez d'autres numéros premium ici
  ],
  
  //  Nom du bot
  botName: '𝙽𝙾𝚇-𝚂𝙿𝙰𝙲𝙴',
  
  //  Nom du propriétaire
  ownerName: '©𝐋𝚯𝐑𝐃꙳𝐍𝐎𝐗꙳𝐓𝐄𝐂𝐇꙳🇦🇱',
  
  // 🔗 Lien du propriétaire
  ownerLink: 'T.me/LordNoxTech'
  // ⚙️ Préfixe des commandes
  prefix: '+',
};

// Fonction pour vérifier si un utilisateur est le propriétaire
export function isOwner(userId) {
  return userId === config.owner;
}

// Fonction pour vérifier si un utilisateur est premium
export function isPremium(userId) {
  return config.premium.includes(userId);
}

// Fonction pour vérifier si un utilisateur peut utiliser une commande restreinte
export function canUseRestricted(userId) {
  return isOwner(userId) || isPremium(userId);
}

// Fonction pour ajouter un utilisateur premium (seulement par le owner)
export function addPremium(userId, requesterId) {
  if (!isOwner(requesterId)) {
    return { success: false, message: 'Seul le propriétaire peut ajouter des utilisateurs premium' };
  }
  
  if (isPremium(userId)) {
    return { success: false, message: 'Cet utilisateur est déjà premium' };
  }
  
  config.premium.push(userId);
  return { success: true, message: 'Utilisateur ajouté aux premium avec succès' };
}

// Fonction pour retirer un utilisateur premium
export function removePremium(userId, requesterId) {
  if (!isOwner(requesterId)) {
    return { success: false, message: 'Seul le propriétaire peut retirer des utilisateurs premium' };
  }
  
  const index = config.premium.indexOf(userId);
  if (index === -1) {
    return { success: false, message: 'Cet utilisateur n\'est pas premium' };
  }
  
  config.premium.splice(index, 1);
  return { success: true, message: 'Utilisateur retiré des premium avec succès' };
}