# NOX-SPACE

Bot WhatsApp multi-fonctions

Start:
```
npm install
npm run dev
```

Rename/configure as needed.
