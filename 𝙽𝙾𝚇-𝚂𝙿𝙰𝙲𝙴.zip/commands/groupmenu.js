export default async (sock, msg, config) => {
  const text = `
┏❍ *𝙶𝚁𝙾𝚄𝙿-𝙼𝙴𝙽𝚄* ❍
┃ • ${config.prefix}add <number>
┃ • ${config.prefix}kick <@user>
┃ • ${config.prefix}promote <@user>
┃ • ${config.prefix}demote <@user>
┃ • ${config.prefix}tagall
┃ • ${config.prefix}welcome <on|off>
┃ • ${config.prefix}bye <on|off>
┗❏ *𝙽𝙾𝚇-𝚂𝙿𝙰𝙲𝙴* ❍`;
  await sock.sendMessage(msg.key.remoteJid, { text });
};
