export default async (sock, msg, config) => {
  const text = `
┏❍ *𝚂𝙲𝚁𝙸𝙿𝚃* ❍
┃ • 𝙱𝙾𝚃 𝙼𝙰𝙳𝙴 𝙱𝚈 : 𝐋𝚯𝐑𝐃꙳𝐍𝐎𝐗
┃ • 𝙶𝙸𝚃 𝙻𝙸𝙽𝙺 : https://github.com/devdarknox/Nox-space-bot
┃ • 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : 1.0.0
┗❏ *𝙽𝙾𝚇-𝚂𝙿𝙰𝙲𝙴* ❍`;
  await sock.sendMessage(msg.key.remoteJid, { text });
};
