import fs from 'fs';
import path from 'path';
import config from '../config.js';

export default async (sock, msg, args) => {
  try {
    const sender = msg.key.participant || msg.key.remoteJid;
    // check owner - owner in config may be a number or id
    const ownerId = (config.owner && config.owner.toString()) || '';
    if (!ownerId || !sender.includes(ownerId)) {
      await sock.sendMessage(msg.key.remoteJid, { text: '❌ Accès refusé — seulement le owner peut changer le préfixe.' });
      return;
    }
    const newPrefix = args.join(' ').trim();
    if (!newPrefix) {
      await sock.sendMessage(msg.key.remoteJid, { text: 'Usage: ' + config.prefix + 'setprefix <nouveau_pref>' });
      return;
    }
    const configPath = path.join(process.cwd(), 'config.js');
    let content = fs.readFileSync(configPath, 'utf8');
    // naive replace for prefix in config file
    content = content.replace(/(prefix\s*[:=]\s*['\"])[^'\"]+(['\"])/, '$1' + newPrefix + '$2');
    fs.writeFileSync(configPath, content, 'utf8');
    // reply
    await sock.sendMessage(msg.key.remoteJid, { text: '✅ Préfixe changé en: ' + newPrefix });
  } catch (e) {
    console.error(e);
    await sock.sendMessage(msg.key.remoteJid, { text: '⚠️ Erreur: ' + e.message });
  }
};
