export default async (sock, msg, config) => {
  const text = `
┏❍ *𝙽𝙾𝚇* ❍
┃ • 𝙱𝚘𝚝 𝙾𝚏𝚏𝚒𝚌𝚒𝚎𝚕 𝙳𝚎 : 𝐋𝚯𝐑𝐃꙳𝐍𝐎𝐗꙳🇦🇱
┃ • 𝙽𝙾𝚇 𝚃𝙴𝙲𝙷 | 𝙻𝙴𝙶𝙴𝙽𝙳
┃ • 𝚂𝚎𝚛𝚟𝚒𝚌𝚎 𝚊𝚌𝚝𝚒𝚏 24/7
┗❏ *𝙽𝙾𝚇-𝚂𝙿𝙰𝙲𝙴* ❍`;
  await sock.sendMessage(msg.key.remoteJid, { text });
};
