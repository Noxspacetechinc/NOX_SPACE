export default async (sock, msg, config) => {
  const text = `
┏❍ *𝙾𝚆𝙽𝙴𝚁-𝙼𝙴𝙽𝚄* ❍
┃ • ${config.prefix}setprefix <car>
┃ • ${config.prefix}restart
┃ • ${config.prefix}block <@user>
┃ • ${config.prefix}unblock <@user>
┃ • ${config.prefix}broadcast <message>
┗❏ *𝙽𝙾𝚇-𝚂𝙿𝙰𝙲𝙴* ❍`;
  await sock.sendMessage(msg.key.remoteJid, { text });
};
