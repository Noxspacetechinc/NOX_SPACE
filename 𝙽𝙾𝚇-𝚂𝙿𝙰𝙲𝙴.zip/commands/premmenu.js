export default async (sock, msg, config) => {
  const text = `
┏❍ *𝙿𝚁𝙴𝙼-𝙼𝙴𝙽𝚄* ❍
┃ • ${config.prefix}antilink <on|off>
┃ • ${config.prefix}antiword <on|off>
┃ • ${config.prefix}antispam <on|off>
┃ • ${config.prefix}autosticker <reply to image>
┃ • ${config.prefix}ai <prompt>
┃ • ${config.prefix}tts <lang|text>
┃ • ${config.prefix}enhance <reply to image>
┃ • ${config.prefix}download <url>
┗❏ *𝙽𝙾𝚇-𝚂𝙿𝙰𝙲𝙴* ❍`;
  await sock.sendMessage(msg.key.remoteJid, { text });
};
