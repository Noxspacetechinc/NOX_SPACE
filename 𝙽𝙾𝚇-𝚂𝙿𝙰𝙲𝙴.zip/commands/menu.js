export default async (sock, msg, config) => {
  const pushName = msg.pushName || "User";

  const menu = `
▣ *𝙽𝙾𝚇-𝚂𝙿𝙰𝙲𝙴* ▣

┏❍ *𝙱𝙾𝚃-𝙸𝙽𝙵𝙾* ❍
┃ • user : ${pushName}
┃ • prefix : ${config.prefix}
┃ • version : 1.0.0
┃ • owner : 𝐋𝚯𝐑𝐃꙳𝐍𝐎𝐗꙳🇦🇱
┗❏ *𝙽𝙾𝚇-𝚂𝙿𝙰𝙲𝙴*❍

┏❍ *𝙼𝙴𝙽𝚄 𝙲𝙼𝙳𝚂* ❍
┃ • ${config.prefix}ownermenu
┃ • ${config.prefix}premmenu
┃ • ${config.prefix}groupmenu
┃ • ${config.prefix}script
┃ • ${config.prefix}nox
┗❏ *𝙽𝙾𝚇-𝚂𝙿𝙰𝙲𝙴* ❍`;

  await sock.sendMessage(msg.key.remoteJid, { text: menu });
};
